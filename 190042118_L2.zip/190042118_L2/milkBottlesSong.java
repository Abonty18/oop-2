public class milkBottlesSong
{

    int bottleNumber=99;
    String bottle=" bottles ";
    String bottle1=" bottle ";
    String part1 = "of milk on the wall, ";
    String part2 = "of milk.";
    String part3 = "Take one down and pass it around,";
    String part4 = "of milk on the wall.";
    String lastPart = "Take it down and pass it around, no more bottles of milk on the wall.\n" +
                      "No more bottles of milk on the wall, no more bottles of milk.\n" +
                      "Go to the store and buy some more, 99 bottles of milk on the wall.";



    void printSong()
    {
        while(bottleNumber>1)
        {
            System.out.println(bottleNumber+bottle+part1+bottleNumber+bottle+part2);//for 99
            bottleNumber=bottleNumber-1;
            if(bottleNumber>1)
            {
                System.out.println(part3 + bottleNumber + bottle+ part4);//for 98
            }


            if(bottleNumber==1)
            {
                System.out.println(part3+bottleNumber+bottle1+part4);
                System.out.println(bottleNumber+bottle1+part1+bottleNumber+bottle1+part2);
            }



        }
        System.out.println(lastPart);
    }

}
