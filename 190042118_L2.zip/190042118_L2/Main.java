public class Main{
	public static void main(String[] args) {
		milkBottlesSong song = new milkBottlesSong();
		song.printSong();
	}
}