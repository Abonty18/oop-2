public abstract class Trip {
    public int distance;
    public int minutes;
    public int number_of_Passenger;

    public Trip(
            int distance,
            int minutes,
            int number_of_Passenger) {
        this.distance = distance;
        this.minutes = minutes;
        this.number_of_Passenger = number_of_Passenger;
    }

    public abstract void requestTrip();



    public abstract int perHeadFare();

    public abstract boolean canTakeTrip();


}
