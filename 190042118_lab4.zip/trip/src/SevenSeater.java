public class SevenSeater extends Trip {
    public SevenSeater(int distance, int minutes, int number_of_Passenger) {
        super(distance, minutes,number_of_Passenger);
    }

    @Override
    public void requestTrip() {
        System.out.println("== Ride with Friends and Family in Seven-Seater ==");
        if (canTakeTrip()) {
            System.out.println(distance + " KM");
            System.out.println(minutes + " Minutes");
            System.out.println(perHeadFare() + " Taka Per Person");
        } else {
            System.out.println("Invalid Trip Request");
        }
    }
    public int perHeadFare(){
        int fare = -1;
        if (distance < 10)
            fare = 300 / number_of_Passenger;
        else
            fare = (distance * 30) / number_of_Passenger;

        return fare - (fare % 5);
    }


    public boolean canTakeTrip(){

        if (number_of_Passenger < 1)
            return false;
        else {
            return number_of_Passenger <= 7 && distance >= 10;
        }
    }

}

