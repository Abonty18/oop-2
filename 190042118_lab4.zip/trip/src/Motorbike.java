class MotorBike extends Trip {
    public MotorBike(int distance, int minutes, int number_of_Passenger) {
        super(distance, minutes, number_of_Passenger);
    }

    @Override
    public void requestTrip() {
        System.out.println("== Ride Swift in Bike ==");
        if (canTakeTrip()) {
            System.out.println(distance + " KM");
            System.out.println(minutes + " Minutes");
            System.out.println(perHeadFare() + " Taka Per Person");
        } else {
            System.out.println("Invalid Trip Request");
        }

    }

    public int perHeadFare(){
        int fare = -1;
        fare = Math.max(25, distance * 20) / number_of_Passenger;

        return fare - (fare % 5);
    }

    public boolean canTakeTrip(){

        if (number_of_Passenger <= 1 && distance<= 10)
            return true;
        else {
            return false;
        }
    }
}
