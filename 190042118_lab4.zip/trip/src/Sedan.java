
public class Sedan extends Trip{
    public Sedan(int distance, int minutes, int number_of_passengers){
        super(distance,minutes,number_of_passengers);

    }
    @Override
    public void requestTrip() {
        System.out.println("== Comfortable Sedan Ride ==");
        if (canTakeTrip()) {
            System.out.println(distance+ " KM");
            System.out.println(minutes + " Minutes");
            System.out.println(perHeadFare() + " Taka Per Person");
        } else {
            System.out.println("Invalid Trip Request");
        }

    }

    public int perHeadFare(){
        int fare = -1;
        fare = (50 + (distance * 30) + (minutes * 2)) / number_of_Passenger ;
        return fare - (fare % 5);
    }

    public boolean canTakeTrip(){

        if (number_of_Passenger >=1 && number_of_Passenger <= 4 && distance <= 25)
            return true;
        else {
            return false;
        }
    }


}
