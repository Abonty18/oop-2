package com.inventory;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class InventoryTest {
    @DisplayName("Checking the increasement of the quality of Aged brie")
    @Test
    void checkAgedBrie() {
        Item[] items = new Item[] { new Item("Aged Brie", 20, 1) };
        Inventory inventory = new Inventory(items);
        inventory.updateQuality();
        assertEquals(2, inventory.items[0].quality);
    }

    @DisplayName("Checking for the quality increasement or decreasement of Aged brie at it's peak stage")
    @Test
    void checkingAgedBrieWhenTheQualityIsHighest() {
        Item[] items = new Item[] { new Item("Aged Brie", 20, 50) };
        Inventory inventory = new Inventory(items);
        inventory.updateQuality();
        assertEquals(50, inventory.items[0].quality);
    }

    @DisplayName("Checking Backstage passes when less than 5 days left")
    @Test
    void checkBackstagePasses() {
        Item[] items = new Item[] { new Item("Backstage passes to a TAFKAL80ETC concert", 5, 30) };
        Inventory inventory = new Inventory(items);
        inventory.updateQuality();
        assertEquals(33, inventory.items[0].quality);
    }

    @DisplayName("Checking for Backstage passes when it exceeds sellin point")
    @Test
    void checkBackstagePassesExceedsSellIn() {
        Item[] items = new Item[] { new Item("Backstage passes to a TAFKAL80ETC concert", 0, 49) };
        Inventory inventory = new Inventory(items);
        inventory.updateQuality();
        assertEquals(0, inventory.items[0].quality);
    }

    @DisplayName("Checking for the value of Sulfuras")
    @Test
    void checkSulfuras() {
        Item[] items = new Item[] { new Item("Sulfuras, Hand of Ragnaros", 20, 35) };
        Inventory inventory = new Inventory(items);
        inventory.updateQuality();
        assertEquals(35, inventory.items[0].quality);
    }

    @DisplayName("Checking for a New ITEM")
    @Test
    void checkNewItem() {
        Item[] items = new Item[] { new Item("Wine", 0, 5) };
        Inventory inventory = new Inventory(items);
        inventory.updateQuality();
        assertEquals(3, inventory.items[0].quality);
    }

    @DisplayName("Checking for multiple ITEMS")
    @Test
    void checkMultipleItems() {
        Item[] items = new Item[] { new Item("Wine", 3, 4),
                new Item("Aged Brie", 20, 1),
                new Item("Backstage passes to a TAFKAL80ETC concert", 3, 48),
                new Item("Sulfuras, Hand of Ragnaros", 20, 1) };
        Inventory inventory = new Inventory(items);
        inventory.updateQuality();
        assertEquals(3, inventory.items[0].quality);
        assertEquals(2, inventory.items[1].quality);
        assertEquals(50, inventory.items[2].quality);
        assertEquals(1, inventory.items[3].quality);
    }

}

